import ErrorBanner from "../components/ErrorBanner.jsx";
import FilterBar from "../components/FilterBar.jsx";
import TaskForm from "../components/TaskForm.jsx";
import TaskList from "../components/TaskList.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import { TaskProvider } from "../context/TaskContext.jsx";

export default function Dashboard() {
  const { user, logout } = useAuth();

  return (
    <main className="min-h-screen bg-gray-100 text-gray-800">
      <div className="mx-auto max-w-2xl px-4 py-10">
        <header className="mb-6 flex items-center justify-between">
          <h1 className="text-3xl font-bold">Task Manager</h1>
          <div className="flex items-center gap-3 text-sm">
            <span className="text-gray-600">Hi, {user.name}</span>
            <button onClick={logout} className="rounded-md bg-gray-800 px-3 py-1.5 text-white hover:bg-gray-900">
              Logout
            </button>
          </div>
        </header>

        {/* TaskProvider mounts only when logged in, so tasks load for the right user */}
        <TaskProvider>
          <ErrorBanner />
          <TaskForm />
          <FilterBar />
          <TaskList />
        </TaskProvider>
      </div>
    </main>
  );
}
